package com.example.livelyvillagers;

import java.util.List;

import net.minecraft.core.Holder;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.EntityTypeTags;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.entity.monster.AbstractIllager;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.npc.Villager;
import net.minecraft.world.entity.npc.VillagerProfession;
import net.minecraft.world.entity.projectile.ThrownPotion;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.alchemy.Potion;
import net.minecraft.world.item.alchemy.PotionContents;
import net.minecraft.world.item.alchemy.Potions;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * Cleric: Regeneration on hurt villagers/iron golems, Healing on undead (harms them),
 * Harming on illagers.
 */
public class ClericSupportGoal extends Goal {
    private static final double RANGE = 12.0;

    private final Villager villager;
    private long nextCheck;
    private LivingEntity target;
    private Holder<Potion> potion;
    private boolean harming;

    public ClericSupportGoal(Villager villager) {
        this.villager = villager;
    }

    @Override
    public boolean canUse() {
        if (!VillagerUtil.isFree(villager) || !VillagerUtil.is(villager, VillagerProfession.CLERIC)) return false;
        long now = villager.level().getGameTime();
        if (now < nextCheck) return false;
        nextCheck = now + 20;

        List<LivingEntity> nearby = villager.level().getEntitiesOfClass(LivingEntity.class,
                villager.getBoundingBox().inflate(RANGE), e -> e != villager && e.isAlive());

        LivingEntity bestEnemy = null;
        Holder<Potion> enemyPotion = null;
        double bestDist = Double.MAX_VALUE;
        LivingEntity bestAlly = null;
        float lowest = 2.0F;
        double ratioLimit = Config.CLERIC_HEALTH_RATIO.get();

        for (LivingEntity e : nearby) {
            double d = villager.distanceToSqr(e);
            if (d > RANGE * RANGE || !villager.hasLineOfSight(e)) continue;

            if (e instanceof Enemy) {
                Holder<Potion> p = null;
                if (e.getType().is(EntityTypeTags.UNDEAD)) p = Potions.HEALING;       // heals = damages undead
                else if (e instanceof AbstractIllager) p = Potions.HARMING;
                if (p == null) continue;
                if (p == Potions.HARMING && VillagerUtil.hasFriendNear(e, 3.5)) continue; // no friendly fire
                if (d < bestDist) {
                    bestDist = d;
                    bestEnemy = e;
                    enemyPotion = p;
                }
            } else if (e instanceof Villager || e instanceof IronGolem) {
                float ratio = e.getHealth() / e.getMaxHealth();
                if (ratio <= ratioLimit && !e.hasEffect(MobEffects.REGENERATION) && ratio < lowest) {
                    lowest = ratio;
                    bestAlly = e;
                }
            }
        }

        if (bestEnemy != null) {
            target = bestEnemy;
            potion = enemyPotion;
        } else if (bestAlly != null) {
            target = bestAlly;
            potion = Potions.REGENERATION;
        } else {
            return false;
        }
        return true;
    }

    @Override
    public boolean canContinueToUse() {
        return false; // one throw per activation
    }

    @Override
    public void start() {
        if (target != null && target.isAlive()) {
            villager.getLookControl().setLookAt(target, 30.0F, 30.0F);
            throwPotion(target, potion);
        }
        nextCheck = villager.level().getGameTime() + Config.CLERIC_COOLDOWN.get();
        target = null;
    }

    private void throwPotion(LivingEntity t, Holder<Potion> p) {
        Level level = villager.level();
        Vec3 vel = t.getDeltaMovement();
        double dx = vel.x + t.getX() - villager.getX();
        double dy = t.getEyeY() - 1.1D - villager.getY();
        double dz = vel.z + t.getZ() - villager.getZ();
        double h = Math.sqrt(dx * dx + dz * dz);

        ThrownPotion thrown = new ThrownPotion(level, villager);
        thrown.setItem(PotionContents.createItemStack(Items.SPLASH_POTION, p));
        thrown.setXRot(thrown.getXRot() + 20.0F);
        thrown.shoot(dx, dy + h * 0.2D, dz, 0.75F, 8.0F);

        level.playSound(null, villager.getX(), villager.getY(), villager.getZ(), SoundEvents.WITCH_THROW,
                villager.getSoundSource(), 1.0F, 0.8F + villager.getRandom().nextFloat() * 0.4F);
        level.addFreshEntity(thrown);
    }
}
