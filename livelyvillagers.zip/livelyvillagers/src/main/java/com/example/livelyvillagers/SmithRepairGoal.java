package com.example.livelyvillagers;

import java.util.EnumSet;
import java.util.List;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.entity.npc.Villager;
import net.minecraft.world.entity.npc.VillagerProfession;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/** Weaponsmith / Toolsmith / Armorer walk to a damaged iron golem and repair it. */
public class SmithRepairGoal extends Goal {
    private final Villager villager;
    private IronGolem golem;
    private long nextCheck;
    private long nextRepair;

    public SmithRepairGoal(Villager villager) {
        this.villager = villager;
        setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    private boolean isSmith() {
        VillagerProfession p = villager.getVillagerData().getProfession();
        return p == VillagerProfession.WEAPONSMITH || p == VillagerProfession.TOOLSMITH
                || p == VillagerProfession.ARMORER;
    }

    @Override
    public boolean canUse() {
        if (!VillagerUtil.isFree(villager) || !isSmith()) return false;
        long now = villager.level().getGameTime();
        if (now < nextCheck) return false;
        nextCheck = now + 20;

        List<IronGolem> golems = villager.level().getEntitiesOfClass(IronGolem.class,
                villager.getBoundingBox().inflate(24.0D, 8.0D, 24.0D),
                g -> g.isAlive() && g.getHealth() < g.getMaxHealth());
        IronGolem best = null;
        double bestDist = Double.MAX_VALUE;
        for (IronGolem g : golems) {
            double d = villager.distanceToSqr(g);
            if (d < bestDist) {
                bestDist = d;
                best = g;
            }
        }
        golem = best;
        return golem != null;
    }

    @Override
    public boolean canContinueToUse() {
        return golem != null && golem.isAlive() && golem.getHealth() < golem.getMaxHealth()
                && VillagerUtil.isFree(villager) && villager.distanceToSqr(golem) < 40.0D * 40.0D;
    }

    @Override
    public void start() {
        nextRepair = 0;
        villager.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.IRON_INGOT));
        villager.setDropChance(EquipmentSlot.MAINHAND, 0.0F);
    }

    @Override
    public void tick() {
        villager.getLookControl().setLookAt(golem, 30.0F, 30.0F);
        long now = villager.level().getGameTime();

        if (villager.distanceToSqr(golem) <= 2.8D * 2.8D) {
            villager.getNavigation().stop();
            if (now >= nextRepair) {
                nextRepair = now + 40;
                golem.heal(Config.SMITH_HEAL.get().floatValue());
                golem.playSound(SoundEvents.IRON_GOLEM_REPAIR, 1.0F,
                        1.0F + (golem.getRandom().nextFloat() - golem.getRandom().nextFloat()) * 0.2F);
                villager.swing(InteractionHand.MAIN_HAND);
                if (villager.level() instanceof ServerLevel sl) {
                    sl.sendParticles(ParticleTypes.HAPPY_VILLAGER, golem.getX(), golem.getY() + 1.5D,
                            golem.getZ(), 5, 0.4D, 0.5D, 0.4D, 0.0D);
                }
            }
        } else if (villager.tickCount % 10 == 0 || villager.getNavigation().isDone()) {
            villager.getNavigation().moveTo(golem, 0.6D);
        }
    }

    @Override
    public void stop() {
        villager.getNavigation().stop();
        if (villager.getMainHandItem().is(Items.IRON_INGOT)) {
            villager.setItemSlot(EquipmentSlot.MAINHAND, ItemStack.EMPTY);
        }
        golem = null;
        nextCheck = villager.level().getGameTime() + 60;
    }
}
