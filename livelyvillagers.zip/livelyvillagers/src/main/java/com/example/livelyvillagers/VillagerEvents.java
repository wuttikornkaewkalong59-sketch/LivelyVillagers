package com.example.livelyvillagers;

import java.util.Map;
import java.util.WeakHashMap;

import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.npc.Villager;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.phys.EntityHitResult;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.EntityJoinLevelEvent;
import net.neoforged.neoforge.event.entity.ProjectileImpactEvent;
import net.neoforged.neoforge.event.entity.living.LivingDamageEvent;

@EventBusSubscriber(modid = LivelyVillagers.MOD_ID)
public class VillagerEvents {
    private static final Map<Villager, Long> COUNTER_READY = new WeakHashMap<>();

    /** Give every villager the new behaviours; each goal checks the profession itself. */
    @SubscribeEvent
    public static void onJoin(EntityJoinLevelEvent event) {
        if (event.getLevel().isClientSide()) return;
        if (event.getEntity() instanceof Villager v) {
            v.goalSelector.addGoal(2, new ClericSupportGoal(v));
            v.goalSelector.addGoal(2, new FletcherShootGoal(v));
            v.goalSelector.addGoal(3, new SmithRepairGoal(v));
        }
    }

    /** Peaceful, but not cowardly: sometimes hit back at a monster that hurt them in melee. */
    @SubscribeEvent
    public static void onDamaged(LivingDamageEvent.Post event) {
        if (!(event.getEntity() instanceof Villager v) || v.level().isClientSide()) return;
        if (!v.isAlive() || v.isBaby()) return;
        if (!(event.getSource().getEntity() instanceof Mob attacker) || !(attacker instanceof Enemy)) return;
        if (v.distanceToSqr(attacker) > 3.5D * 3.5D) return; // melee only

        long now = v.level().getGameTime();
        Long ready = COUNTER_READY.get(v);
        if (ready != null && now < ready) return;
        if (v.getRandom().nextDouble() >= Config.COUNTER_CHANCE.get()) return;

        COUNTER_READY.put(v, now + Config.COUNTER_COOLDOWN.get());
        v.swing(InteractionHand.MAIN_HAND);
        attacker.hurt(v.damageSources().mobAttack(v), Config.COUNTER_DAMAGE.get().floatValue());
        attacker.knockback(0.4D, v.getX() - attacker.getX(), v.getZ() - attacker.getZ());
    }

    /** Villager arrows pass through villagers, golems and players. */
    @SubscribeEvent
    public static void onImpact(ProjectileImpactEvent event) {
        if (event.getProjectile() instanceof AbstractArrow arrow
                && arrow.getOwner() instanceof Villager
                && event.getRayTraceResult() instanceof EntityHitResult hit
                && VillagerUtil.isFriendly(hit.getEntity())) {
            event.setCanceled(true);
        }
    }
}
