package com.example.livelyvillagers;

import net.neoforged.neoforge.common.ModConfigSpec;

public class Config {
    private static final ModConfigSpec.Builder B = new ModConfigSpec.Builder();

    public static final ModConfigSpec.DoubleValue COUNTER_CHANCE = B
            .comment("Chance (0-1) that a villager hits back when a monster hurts it in melee")
            .defineInRange("counterAttackChance", 0.25, 0.0, 1.0);
    public static final ModConfigSpec.DoubleValue COUNTER_DAMAGE = B
            .comment("Damage of a villager counter-attack")
            .defineInRange("counterAttackDamage", 3.0, 0.0, 100.0);
    public static final ModConfigSpec.IntValue COUNTER_COOLDOWN = B
            .comment("Ticks between counter-attacks of the same villager")
            .defineInRange("counterAttackCooldownTicks", 100, 0, 72000);

    public static final ModConfigSpec.IntValue CLERIC_COOLDOWN = B
            .comment("Ticks between potion throws of a cleric")
            .defineInRange("clericThrowCooldownTicks", 100, 20, 72000);
    public static final ModConfigSpec.DoubleValue CLERIC_HEALTH_RATIO = B
            .comment("Cleric heals villagers/iron golems whose health is at or below this ratio")
            .defineInRange("clericHealthRatio", 0.6, 0.05, 1.0);

    public static final ModConfigSpec.DoubleValue SMITH_HEAL = B
            .comment("Health restored to an iron golem per repair")
            .defineInRange("smithHealAmount", 20.0, 1.0, 100.0);

    public static final ModConfigSpec.IntValue FLETCHER_RANGE = B
            .comment("Fletcher shooting range in blocks")
            .defineInRange("fletcherRange", 16, 4, 48);
    public static final ModConfigSpec.IntValue FLETCHER_REST = B
            .comment("Ticks a fletcher rests after a burst of 3 arrows")
            .defineInRange("fletcherRestTicks", 80, 0, 72000);

    public static final ModConfigSpec SPEC = B.build();
}
