package com.example.livelyvillagers;

import java.util.EnumSet;
import java.util.List;

import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.npc.Villager;
import net.minecraft.world.entity.npc.VillagerProfession;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/** Fletcher shoots short bursts of arrows at hostile mobs. */
public class FletcherShootGoal extends Goal {
    private final Villager villager;
    private LivingEntity target;
    private long nextCheck;
    private long nextShot;
    private int shotsLeft;

    public FletcherShootGoal(Villager villager) {
        this.villager = villager;
        setFlags(EnumSet.of(Flag.LOOK));
    }

    private double range() {
        return Config.FLETCHER_RANGE.get();
    }

    @Override
    public boolean canUse() {
        if (!VillagerUtil.isFree(villager) || !VillagerUtil.is(villager, VillagerProfession.FLETCHER)) return false;
        long now = villager.level().getGameTime();
        if (now < nextCheck) return false;
        nextCheck = now + 20;

        double r = range();
        List<LivingEntity> list = villager.level().getEntitiesOfClass(LivingEntity.class,
                villager.getBoundingBox().inflate(r), e -> e instanceof Enemy && e.isAlive());
        LivingEntity best = null;
        double bestDist = r * r;
        for (LivingEntity e : list) {
            double d = villager.distanceToSqr(e);
            if (d <= bestDist && villager.hasLineOfSight(e)) {
                bestDist = d;
                best = e;
            }
        }
        target = best;
        return target != null;
    }

    @Override
    public boolean canContinueToUse() {
        return target != null && target.isAlive() && shotsLeft > 0 && VillagerUtil.isFree(villager)
                && villager.distanceToSqr(target) <= range() * range() && villager.hasLineOfSight(target);
    }

    @Override
    public void start() {
        shotsLeft = 3;
        nextShot = villager.level().getGameTime() + 10;
        villager.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.BOW));
        villager.setDropChance(EquipmentSlot.MAINHAND, 0.0F);
    }

    @Override
    public void tick() {
        villager.getLookControl().setLookAt(target, 30.0F, 30.0F);
        long now = villager.level().getGameTime();
        if (now >= nextShot) {
            shoot();
            shotsLeft--;
            nextShot = now + 20;
        }
    }

    private void shoot() {
        AbstractArrow arrow = ProjectileUtil.getMobArrow(villager, new ItemStack(Items.ARROW), 1.0F, null);
        arrow.pickup = AbstractArrow.Pickup.DISALLOWED;
        double dx = target.getX() - villager.getX();
        double dy = target.getY(0.3333333333333333D) - arrow.getY();
        double dz = target.getZ() - villager.getZ();
        double h = Math.sqrt(dx * dx + dz * dz);
        arrow.shoot(dx, dy + h * 0.2D, dz, 1.6F, 14 - villager.level().getDifficulty().getId() * 4);
        villager.playSound(SoundEvents.SKELETON_SHOOT, 1.0F,
                1.0F / (villager.getRandom().nextFloat() * 0.4F + 0.8F));
        villager.level().addFreshEntity(arrow);
    }

    @Override
    public void stop() {
        if (villager.getMainHandItem().is(Items.BOW)) {
            villager.setItemSlot(EquipmentSlot.MAINHAND, ItemStack.EMPTY);
        }
        target = null;
        nextCheck = villager.level().getGameTime() + Config.FLETCHER_REST.get();
    }
}
