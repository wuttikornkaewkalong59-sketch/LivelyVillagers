package com.example.livelyvillagers;

import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.config.ModConfig;

@Mod(LivelyVillagers.MOD_ID)
public class LivelyVillagers {
    public static final String MOD_ID = "livelyvillagers";

    public LivelyVillagers(IEventBus modEventBus, ModContainer container) {
        container.registerConfig(ModConfig.Type.COMMON, Config.SPEC);
    }
}
