package com.example.livelyvillagers;

import java.util.List;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.entity.npc.Villager;
import net.minecraft.world.entity.npc.VillagerProfession;
import net.minecraft.world.entity.player.Player;

final class VillagerUtil {
    private VillagerUtil() {}

    static boolean is(Villager v, VillagerProfession p) {
        return v.getVillagerData().getProfession() == p;
    }

    /** Alive, adult, awake and not trading. */
    static boolean isFree(Villager v) {
        return v.isAlive() && !v.isBaby() && !v.isSleeping() && v.getTradingPlayer() == null;
    }

    static boolean isFriendly(Entity e) {
        return e instanceof Villager || e instanceof IronGolem || e instanceof Player;
    }

    static boolean hasFriendNear(LivingEntity target, double radius) {
        List<LivingEntity> list = target.level().getEntitiesOfClass(LivingEntity.class,
                target.getBoundingBox().inflate(radius), e -> e != target && isFriendly(e));
        return !list.isEmpty();
    }
}
